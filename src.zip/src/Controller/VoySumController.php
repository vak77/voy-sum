<?php

namespace App\Controller;


use App\Lib\LibVoySumClass;
use App\Model\DataBaseAdapterClass;
use App\Model\ModelClass;
use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\RequestException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Dotenv\Dotenv;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\KernelInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Yaml\Yaml;
use function getenv;

/**
 * Class VoySumController
 * @Route("/voysum")
 * @package App\Controller
 */
class VoySumController extends AbstractController
{
  private $dbConnection, $dbName, $dbHost, $dbPort, $sqlYaml;
  private $guzzleClient, $endPoint, $endPointDbHost;

  public function StatusCodeHandling(RequestException $e)
  {
    if ($e->getResponse()->getStatusCode() == '400')
    {
      //$this->prepare_access_token();
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
    elseif ($e->getResponse()->getStatusCode() == '422')
    {
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
    elseif ($e->getResponse()->getStatusCode() == '500')
    {
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
    elseif ($e->getResponse()->getStatusCode() == '401')
    {
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
    elseif ($e->getResponse()->getStatusCode() == '403')
    {
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
    else
    {
      $response = json_decode($e->getResponse()->getBody()->getContents());
      return $response;
    }
  }

  //public function __construct( RequestStack $requestStack, KernelInterface $kernel, LibVoySumClass $libVoySumClass, DataBaseAdapterClass $dataBaseAdapterClass)
  public function __construct( RequestStack $requestStack, KernelInterface $kernel, DataBaseAdapterClass $dataBaseAdapterClass)
  {
    $this->dbConnection = $this->dbName = $this->dbHost = $this->dbPort = $this->sqlYaml = null;
    $this->guzzleClient = $this->endPoint = $this->endPointDbHost = null;

    $sqlDir = $kernel->getProjectDir() . "/config/sql/";
    $this->sqlYaml = Yaml::parseFile($sqlDir . "voy-sum.yaml");

    $dotenv = new Dotenv(true);
    $dotenv->loadEnv($kernel->getProjectDir() . "/.env");

    $this->dbName = $requestStack->getCurrentRequest()->get('dbname') ?: null;
      $dbHostArray = explode(":", $requestStack->getCurrentRequest()->get('dbhost') ?: null);  //    >attributes->get('dbhost') ?: null;

    if($dbHostArray)
    {
      $this->dbHost = $dbHostArray[0];
      $this->dbPort = ((count($dbHostArray) > 1) ? $dbHostArray[1] : "5432");
    }

    // A "\" before the beginning of a function represents the Global Namespace
    // or "use <function name>;" <===== among other "use" at the top of the file
    $this->endPoint = getenv('SUMREC_ENDPOINT');
    $this->endPointDbHost = getenv('SUMREC_DBHOST');

    $this->guzzleClient = new Client();

    $dataBaseAdapterClass->setConnection($this->dbName, $this->dbHost, $this->dbPort);
    $this->dbConnection = $dataBaseAdapterClass->getDbConnection();
    try
    {
      $this->dbConnection->ping();
    }
    catch(Exception $e)
    {
      $errMessage = str_replace('"', '\'', $e->getMessage()) . " **** " .
        "DB = ".$this->dbConnection->getParams()['dbname'] .
        ", HOST = " . $this->dbConnection->getParams()['host'] . ":" . $this->dbConnection->getParams()['port'] . "";
        $errArray = ['Error' => ["No Connection to the database" => $errMessage]];
        die(json_encode($errArray, JSON_PRETTY_PRINT));
    }

  }

  /**
   * @Route("/reclist/{voyId}", name="reclist", requirements={"voyId"="\d+"})
   * @param ModelClass $modelClass
   * @param LibVoySumClass $libVoySumClass
   * @param $voyId
   * @return Response
   */
  public function getSumRecList( ModelClass $modelClass, LibVoySumClass $libVoySumClass, $voyId)
  {
    if(!$this->dbConnection)
      //return new Response("No Connection to the database [". $this->dbname . "] on host [" . $this->dbhost . "]");
      return $this->json("No Connection to the database [" . $this->dbName . "] on host [" . $this->dbHost . "]");

    $retArray = $modelClass->getRecList($this->sqlYaml['common']['get_rec_list'], $voyId);
/*
    $response = new Response();
    $response->setContent(json_encode( $retArray, JSON_UNESCAPED_SLASHES));
    $response->headers->set('Content-Type', 'application/json');
    $response->headers->set('Access-Control-Allow-Origin', '*');
    return $response;
    */
    return $libVoySumClass->setResponse($retArray);
  }

  /**
   * @Route("/subreplist/{voyId}", name="subreplist", requirements={"voyId"="\d+"})
   * @param ModelClass $modelClass
   * @param LibVoySumClass $libVoySumClass
   * @param $voyId
   * @return JsonResponse|Response
   */
  public function getSubRepList( ModelClass $modelClass, LibVoySumClass $libVoySumClass, $voyId)
  {
    if(!$this->dbConnection)
      //return new Response("No Connection to the database [". $this->dbname . "] on host [" . $this->dbhost . "]");
      return $this->json("No Connection to the database [" . $this->dbName . "] on host [" . $this->dbHost . "]");

    $retArray = null;
    $retSubReportsArray = $modelClass->getSubReports($this->sqlYaml['common'], $voyId);
    if($retSubReportsArray['retCode'])
      $retArray = $retSubReportsArray['subRepArray'];
    else
      $retArray = ['Error' => 'No Sub-Reports'];

    return $libVoySumClass->setResponse($retArray);
  }

  /**
   * @Route("/getendpoint", name="getendpoint")
   * @param LibVoySumClass $libVoySumClass
   * @return array|false|string
   */
  public function getEndPoint(LibVoySumClass $libVoySumClass)
  {
    return $libVoySumClass->setResponse( $this->endPoint);
  }

  /**
   * @Route("/postsumrec", name="postsumrec", methods={"POST"})
   * @param Request $request
   * @param LibVoySumClass $libVoySumClass
   * @return Response
   */
  public function postSumRec(Request $request, LibVoySumClass $libVoySumClass)
  {
    $postDataJson = $request->getContent();
    $postDataJsonArray = json_decode($postDataJson, true);

    return $libVoySumClass->setResponse( "privet");

  }

  /**
   * @Route("/sumrec/{voyId}/{reportType?'EOV'}/{reportId?0}/{pointToPoint?}", name="sumrec", requirements={"voyId"="\d+"})
   * @param ModelClass $modelClass
   * @param LibVoySumClass $libVoySumClass
   * @param $voyId
   * @param $reportType
   * @param $reportId
   * @param $pointToPoint
   * @return Response
   */
  public function getSumRec(ModelClass $modelClass, LibVoySumClass $libVoySumClass, $voyId, $reportType, $reportId, $pointToPoint)
  {
    $argsArray = ['voyageid' => $voyId, 'reporttype' => $reportType, 'reportid' => $reportId];

    if(!$this->dbConnection)
      return $this->json("No Connection to the database [". $this->dbName . "] on host [" . $this->dbHost . "]");

    $voyId = intval($voyId);
    $pointToPointArray = ($pointToPoint ? explode(",", $pointToPoint) : null);
    if($reportType === 'MID')
    {
      //if ((!$pointToPointArray || (count($pointToPointArray) != 2)) && (!$reportId))
      if (!$pointToPointArray || (count($pointToPointArray) != 2))
        return $libVoySumClass->setResponse(['Error' => "Report Type is 'MID' but neither 'point-to-point' nor 'report ID' provided"]);
    }

    $retArray = $modelClass->eovReportId($this->sqlYaml['common'], $voyId, $reportType, $reportId);
    if($retArray['reportId'] == 0)
      return $this->json($retArray["errStr"]);
      //return new Response($retArray["errStr"]);
    else
      $reportId = $retArray['reportId'];

    //Create new or update existing summary record
    $gwxResponse = null;
    $result = null;
    try
    {
      // ======> can not create new MID report yet because can not extract piece of voyage yet <==============================
      $gwxResponse =
        $this->guzzleClient->get(
          $this->endPoint . "?voyageid=" . $voyId . "&reporttype=" . $reportType . "&reportid=" . $reportId . "&dbname=" . $this->dbName . "&dbhost=" . $this->endPointDbHost
        );
      $result = $gwxResponse->getBody()->getContents();
    }
    catch (GuzzleException $e) {
      $result = $this->StatusCodeHandling($e);
    }

    $retValsArray = null;
    $voySumArray = null;
    $retArray = $modelClass->getVoysumJson($this->sqlYaml['common'], $voyId, $reportType, $reportId);

    //$retCode = $retArray['retCode'];
    if($retArray['retCode'])
    {
      $voySumArray = json_decode($retArray['voySumJson'], true);

      $retArray = $modelClass->getCpgwxArray($this->sqlYaml['common'], $voyId);
      if($retArray['retCode'])
        $voySumArray['cpgwx'] = $retArray['cpGwxArray'];
      else
        $voySumArray['cpgwx'] = null;

      $voySumArray['wxfacgw'] = array_fill(0, count($voySumArray['wxfacgw']), 0.0); //  <===== make "wxfacgw" all 0.0

      $voySumArray = $libVoySumClass->setCpConsByLeg($voySumArray);
      $voySumArray = $libVoySumClass->setPerfValsPerCpTerm($voySumArray);

      $argsArray = ['voyageid' => $voyId, 'reporttype' => $reportType, 'reportid' => $reportId];
      //$retInt = array_unshift($voySumArray, $argsArray);
      //$voySumArray = $argsArray + $voySumArray;
      $voySumArray = array_merge($argsArray, $voySumArray);

      /*
      $retArray = $modelClass->getCpgwxArray($this->sqlYaml['common'], $voyId);
      if($retArray['retCode'])
        $voySumArray['cpgwx'] = $retArray['cpGwxArray'];
      */

    }

    //return $libVoySumClass->setResponse(['Error' => $retArray['errStr']]);
    return $libVoySumClass->setResponse($voySumArray);
  }


  /**
   * @Route("/sumrec_I/{voyId}/{reportType?'EOV'}/{reportId?0}/{pointToPoint?}", name="sumrec_I", requirements={"voyId"="\d+"})
   //* Route("/sumrec", name="sumrec")
   * @param KernelInterface $kernel
   * @param Request $request
   * @param ModelClass $modelClass
   * @param LibVoySumClass $libVoySumClass
   * @param $voyId
   * @param $reportType
   * @param $reportId
   * @param $pointToPoint
   * @return Response
   */
  public function getSumRec_I(KernelInterface $kernel, Request $request, ModelClass $modelClass, LibVoySumClass $libVoySumClass, $voyId, $reportType, $reportId, $pointToPoint )
  {
    if(!$this->dbConnection)
      //return new Response("No Connection to the database [". $this->dbname . "] on host [" . $this->dbhost . "]");
      return $this->json("No Connection to the database [". $this->dbName . "] on host [" . $this->dbHost . "]");

    $voyId = intval($voyId);
    $pointToPointArray = ($pointToPoint ? explode(",", $pointToPoint) : null);
    if($reportType === 'MID')
    {
      if ((!$pointToPointArray || (count($pointToPointArray) != 2)) && (!$reportId))
        return $this->json("Report Type is 'MID' but neither 'point-to-point' nor 'report ID' provided");
    }

    /*
    $reportType = (
      ($reportType === 'EOV') ? $reportType :
      (( $pointToPointArray && (count($pointToPointArray) == 2) && ctype_digit(implode("", $pointToPointArray)) ) ? "MID" : "EOV")
  );
    */

    //$sqlDir = $kernel->getProjectDir() . "/config/sql/";
    //$this->sqlYaml = Yaml::parseFile($sqlDir . "voy-sum.yaml");

    //$retArray = $modelClass->eovReportId($this->sqlYaml['common'], $voyId, $reportType, 0);
    $retArray = $modelClass->eovReportId($this->sqlYaml['common'], $voyId, $reportType, $reportId);

    if($retArray['reportId'] == 0)
      return $this->json($retArray["errStr"]);
      //return new Response($retArray["errStr"]);
    else
      $reportId = $retArray['reportId'];

    //Create new or update existing summary record
    $gwxResponse = null;
    $result = null;
    try
    {
      // ======> can not create new MID report yet because can not extract piece of voyage yet <==============================
      $gwxResponse =
        $this->guzzleClient->get(
          $this->endPoint . "?voyageid=" . $voyId . "&reporttype=" . $reportType . "&reportid=" . $reportId . "&dbname=" . $this->dbName . "&dbhost=" . $this->endPointDbHost
        );
      $result = $gwxResponse->getBody()->getContents();
    }
    /*catch(RequestException $e)
    {
      $gwxResponse = $this->StatusCodeHandling($e);
    }*/
    catch (RequestException $e)
    {
      $result = $this->StatusCodeHandling($e);
    }

    /*
    $retArray = $modelClass->eovReportId($this->sqlYaml['common'], $voyId, $reportType, $reportId);
    if($retArray['reportId'] ==0)
      return $this->json($retArray["errStr"]);
    */

    $retValsArray = null;
    $voySumArray = null;
    $retArray = $modelClass->getVoysumJson($this->sqlYaml['common'], $voyId, $reportType, $reportId);
    if($retArray['retCode'])
    {
      $voySumArray = json_decode($retArray['voySumJson'], true);
      //$voySumArray = $retArray['voySumArray'];
      $voySumArray['wxfacgw'] = array_fill(0, count($voySumArray['wxfacgw']), 0.0); //  <===== make "wxfacgw" all 0.0


      $voySumArray = $libVoySumClass->setCpConsByLeg($voySumArray);

      $voySumArray['ifoallowtotal'] = $voySumArray['ifocpval'];
        $voySumArray['ifoallowtotal'] = array_map( function($val) { return round((($val > 0.0) ? $val : 0.0) / 24.0, 2); }, $voySumArray['ifoallowtotal']);
        $voySumArray['ifoallowgw'] = $voySumArray['ifoallowtotal'];
      $voySumArray['hfoallowtotal'] = $voySumArray['hfocpval'];
        $voySumArray['hfoallowtotal'] = array_map( function($val) { return round((($val > 0.0) ? $val : 0.0) / 24.0, 2); }, $voySumArray['hfoallowtotal']);
        $voySumArray['hfoallowgw'] = $voySumArray['hfoallowtotal'];
      $voySumArray['mdoallowtotal'] = $voySumArray['mdocpval'];
        $voySumArray['mdoallowtotal'] = array_map( function($val) { return round((($val > 0.0) ? $val : 0.0) / 24.0, 2); }, $voySumArray['mdoallowtotal']);
        $voySumArray['mdoallowgw'] = $voySumArray['mdoallowtotal'];
      $voySumArray['mgoallowtotal'] = $voySumArray['mgocpval'];
        $voySumArray['mgoallowtotal'] = array_map( function($val) { return round((($val > 0.0) ? $val : 0.0) / 24.0, 2); }, $voySumArray['mgoallowtotal']);
        $voySumArray['mgoallowgw'] = $voySumArray['mgoallowtotal'];

      //$voySumArray['hfoallowtotal'] = array_fill(0, count($voySumArray['legnum']), 0.0); //  <===== make "wxfacgw" all 0.0
        //$voySumArray['mdoallowtotal'] = array_fill(0, count($voySumArray['legnum']), 0.0); //  <===== make "wxfacgw" all 0.0
        //$voySumArray['mgoallowtotal'] = array_fill(0, count($voySumArray['legnum']), 0.0); //  <===== make "wxfacgw" all 0.0

      $retValsArray = $libVoySumClass->setOverallVals($voySumArray);

      $retArray = $modelClass->getCpgwxArray($this->sqlYaml['common'], $voyId);
      if($retArray['retCode'])
      {
        //$cpgwxJson = json_decode($retArray['cpgwxJson'], true);
        //$retValsArray['cpgwx'] = $cpgwxJson;
        $retValsArray['cpgwx'] = $retArray['cpGwxArray'];
      }

      /*
      $retValsArray['subReps'] = null;
      $retSubReportsArray = $modelClass->getSubReports($this->sqlYaml['common'], $voyId);
      if($retSubReportsArray['retCode'])
      {
        $retValsArray['subReps'] = $retSubReportsArray['subRepArray'];
      }
      */

      $retValsArray['reporttype'] = $reportType;
      $retValsArray['reportid'] = $reportId;

      //$distTotalArray = $voySumArray['disttotal'];
    }
    /*
    $dbParams = $this->dbConnection->getParams();
    return new Response(json_encode(array(
      "a" => $voyId, "repType" => $reportType, "dbName" => $dbParams['dbname'], "dbHost" => $dbParams['host'] . ":" . $dbParams['port']
    )));
    */

    //return new Response($retValsArray);
    //return $this->json($result);
    //return $this->json($retArray);


    //$fff = $this->json($retValsArray);
    //return $this->json($retValsArray);

/*
    $response = new Response();
      $response->setContent(json_encode($retValsArray, JSON_UNESCAPED_SLASHES));
      $response->headers->set('Content-Type', 'application/json');
      $response->headers->set('Access-Control-Allow-Origin', '*');
      return $response;
      */
    return $libVoySumClass->setResponse($retValsArray);

  }
}
